//
//  FirstViewController.swift
//  pizzas
//
//  Created by Jorge Rochín. on 10/11/16.
//  Copyright © 2016 Jorge Rochín. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource{

    @IBOutlet weak var tamaño: UIPickerView!

    var tamaños = ["Chica","Mediana","Grande"]
    var elTamaño = " "
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.tamaño.delegate = self
        self.tamaño.dataSource = self
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return tamaños.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        elTamaño = tamaños[row]
        return elTamaño
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        elTamaño = tamaños[row]
        print(elTamaño)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let sigVista=segue.destination as! TuPizzaViewController
        sigVista.tuPizzaTamaño = elTamaño
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

