//
//  IngredientesViewController.swift
//  pizzas
//
//  Created by Jorge Rochín. on 12/11/16.
//  Copyright © 2016 Jorge Rochín. All rights reserved.
//

import UIKit

class IngredientesViewController: UIViewController {

    @IBOutlet weak var swJamon: UISwitch!
    @IBOutlet weak var lbJamon: UILabel!
    @IBOutlet weak var swPepperoni: UISwitch!
    @IBOutlet weak var lbPepperoni: UILabel!
    @IBOutlet weak var swPavo: UISwitch!
    @IBOutlet weak var lbPavo: UILabel!
    @IBOutlet weak var swSalchicha: UISwitch!
    @IBOutlet weak var lbSalchicha: UILabel!
    @IBOutlet weak var swAceituna: UISwitch!
    @IBOutlet weak var lbAceituna: UILabel!
    @IBOutlet weak var swCebolla: UISwitch!
    @IBOutlet weak var lbCebolla: UILabel!
    @IBOutlet weak var swPimiento: UISwitch!
    @IBOutlet weak var lbPimiento: UILabel!
    @IBOutlet weak var swPiña: UISwitch!
    @IBOutlet weak var lbPiña: UILabel!
    @IBOutlet weak var swTocino: UISwitch!
    @IBOutlet weak var lbTocino: UILabel!
    @IBOutlet weak var swChampiñon: UISwitch!
    @IBOutlet weak var lbChampiñon: UILabel!

    var myAlert = UIAlertController(title: "Atención!!", message: "Seleccionar hasta cinco ingredientes", preferredStyle: UIAlertControllerStyle.alert);
    let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default){(ACTION) in
    }
    
    @IBAction func swJamon(_ sender: Any) {
        if contarIngrdientes() > 5 {
            self.present(myAlert, animated: true, completion: nil);
            self.swJamon.isOn = false;
        }
    }
    
    @IBAction func swPepperoni(_ sender: Any) {
        if contarIngrdientes() > 5 {
            self.present(myAlert, animated: true, completion: nil);
            self.swPepperoni.isOn = false
        }
    }
    
    @IBAction func swPavo(_ sender: Any) {
        if contarIngrdientes() > 5 {
            self.present(myAlert, animated: true, completion: nil);
            self.swPavo.isOn = false
        }
    }
    
    @IBAction func swSalchicha(_ sender: Any) {
        if contarIngrdientes() > 5 {
            self.present(myAlert, animated: true, completion: nil);
            self.swSalchicha.isOn = false
        }
    }
    
    @IBAction func swAceituna(_ sender: Any) {
        if contarIngrdientes() > 5 {
            self.present(myAlert, animated: true, completion: nil);
            self.swAceituna.isOn = false
        }
    }
    
    @IBAction func swCebolla(_ sender: Any) {
        if contarIngrdientes() > 5 {
            self.present(myAlert, animated: true, completion: nil);
            self.swCebolla.isOn = false
        }
    }
    
    @IBAction func swPimiento(_ sender: Any) {
        if contarIngrdientes() > 5 {
            self.present(myAlert, animated: true, completion: nil);
            self.swPimiento.isOn = false
        }
    }
    
    @IBAction func swPiña(_ sender: Any) {
        if contarIngrdientes() > 5 {
            self.present(myAlert, animated: true, completion: nil);
            self.swPiña.isOn = false
        }
    }
    
    @IBAction func swTocino(_ sender: Any) {
        if contarIngrdientes() > 5 {
            self.present(myAlert, animated: true, completion: nil);
            self.swTocino.isOn = false
        }
    }
    
    @IBAction func swChampiñon(_ sender: Any) {
        if contarIngrdientes() > 5 {
            self.present(myAlert, animated: true, completion: nil);
            self.swChampiñon.isOn = false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        myAlert.addAction(okAction);
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func contarIngrdientes() -> Int {
        var cuantos = 0
        
        if swJamon.isOn {
            print(lbJamon.text ?? " ")
            cuantos += 1
        }
        if swPepperoni.isOn {
            print(lbPepperoni.text ?? " ")
            cuantos += 1
        }
        if swPavo.isOn {
            print(lbPavo.text ?? " ")
            cuantos += 1
        }
        if swSalchicha.isOn {
            print(lbSalchicha.text ?? " ")
            cuantos += 1
        }
        if swAceituna.isOn {
            print(lbAceituna.text ?? " ")
            cuantos += 1
        }
        if swCebolla.isOn {
            print(lbCebolla.text ?? " ")
            cuantos += 1
        }
        if swPimiento.isOn {
            print(lbPimiento.text ?? " ")
            cuantos += 1
        }
        if swPiña.isOn {
            print(lbPiña.text ?? " ")
            cuantos += 1
        }
        if swTocino.isOn {
            print(lbTocino.text ?? " ")
            cuantos += 1
        }
        if swChampiñon.isOn {
            print(lbChampiñon.text ?? " ")
            cuantos += 1
        }
    
        return cuantos
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
