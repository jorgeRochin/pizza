//
//  TuPizzaViewController.swift
//  pizzas
//
//  Created by Jorge Rochín. on 13/11/16.
//  Copyright © 2016 Jorge Rochín. All rights reserved.
//

import UIKit

class TuPizzaViewController: UIViewController {
    
    var tuPizzaTamaño:String = ""
    var tuPizzaMasa:String = ""
    var tuPizzaQueso:String = ""
    var tuPizzaIngrediente1:String = ""
    var tuPizzaIngrediente2:String = ""
    var tuPizzaIngrediente3:String = ""
    var tuPizzaIngrediente4:String = ""
    var tuPizzaIngrediente5:String = ""

    @IBOutlet weak var deTamaño: UILabel!
    @IBOutlet weak var deMasa: UILabel!
    @IBOutlet weak var deQueso: UILabel!
    @IBOutlet weak var ingrediente1: UILabel!
    @IBOutlet weak var ingrediente2: UILabel!
    @IBOutlet weak var ingrediente3: UILabel!
    @IBOutlet weak var ingrediente4: UILabel!
    @IBOutlet weak var ingrediente5: UILabel!

    var myAlert = UIAlertController(title: "Gracias!!", message: "Tú pizza estará lista en un momento", preferredStyle: UIAlertControllerStyle.alert);
    let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default){(ACTION) in
    }
    
    @IBAction func preparar(_ sender: Any) {
        self.present(myAlert, animated: true, completion: nil);
        print(tuPizzaTamaño)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        deTamaño.text = tuPizzaTamaño
        deMasa.text = tuPizzaMasa
        deQueso.text = tuPizzaQueso
        ingrediente1.text = tuPizzaIngrediente1
        ingrediente2.text = tuPizzaIngrediente2
        ingrediente3.text = tuPizzaIngrediente3
        ingrediente4.text = tuPizzaIngrediente4
        ingrediente5.text = tuPizzaIngrediente5
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        myAlert.addAction(okAction);
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
